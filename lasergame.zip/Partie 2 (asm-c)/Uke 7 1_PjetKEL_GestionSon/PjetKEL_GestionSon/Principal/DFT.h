//float DFT(float * sig, int k);

int DFT(short int * sig, int k);