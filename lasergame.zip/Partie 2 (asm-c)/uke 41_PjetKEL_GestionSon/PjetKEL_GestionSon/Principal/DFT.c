
//#include "../ServiceDFT/CosSin_float.h"
//#include "../ServiceDFT/Signal_float.h"
//#include "../ServiceDFT/Signal_4_12.h"
#include "../ServiceDFT/CosSin_Fract_1_15.h"


#define M 64

/*
// 200-250 Microsecondes par appel
float DFT(float * sig, int k) {
	float reel = 0.0;
	float imaginaire = 0.0;
	
	for (int i = 0; i < M; i++) {
		reel += (*(sig+i))*TabCos[(k*i)%M];
		imaginaire += (*(sig+i))*TabSin[(k*i)%M];
	}
	
	return reel*reel+imaginaire*imaginaire;
}
*/


int DFT(unsigned short int * sig, int k) {
    unsigned int reel = 0;  // 5.27
    unsigned int imaginaire = 0;  // 5.27

   
    for (int i = 0; i < M; i++) {
        reel += ((*(sig + i)) * TabCos[(k * i) % M] >> 17);  // 5.27
        imaginaire += ((*(sig + i)) * TabSin[(k * i) % M] >> 17);  // 5.27
    }

    
    return ((reel >> 8) * (reel >> 8)) + ((imaginaire >> 8) * (imaginaire >> 8));  // 5.10 + 5.10
}
