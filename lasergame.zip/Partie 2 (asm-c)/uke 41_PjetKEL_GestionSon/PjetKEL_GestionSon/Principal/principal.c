

#include "DriverJeuLaser.h"
#include "ServiceJeuLaser.h"
#include "../GestionSon/GestionSon.h"
#include "DFT.h"
#include "../ServiceDFT/Signal_4_12.h"

/*extern void GestionSon_callback();
extern short int Son;
extern short int SortieSon;
extern long int PeriodeSonMicroSec;*/

int main(void)
{
// ===========================================================================
// ============= INIT PERIPH (faites qu'une seule fois)  =====================
// ===========================================================================

/* Apr�s ex�cution : le coeur CPU est clock� � 72MHz ainsi que tous les timers */
	CLOCK_Configure();
	

/* Configuration du son (voir ServiceJeuLaser.h) 
 Ins�rez votre code d'initialisation des parties mat�rielles g�rant le son ....*/	
	GestionSon_Stop();
	ServJeuLASER_Son_Init(PeriodeSonMicroSec,0,GestionSon_callback);
	//GestionSon_Start();
	
	int dft1[64];
	
	
	// Environ 200-250 microsecondes par appel
	for (int i = 0; i < 64; i++) {
		dft1[i] = DFT(LeSignal, i);
	}
	
	
	

//============================================================================	
	
	
while	(1)
	{
			// PWM_Set_Value_TIM3_Ch3(SortieSon);
	}
}


