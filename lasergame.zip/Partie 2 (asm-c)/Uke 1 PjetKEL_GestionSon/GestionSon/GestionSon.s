	PRESERVE8
	THUMB   
		

; ====================== zone de r�servation de donn�es,  ======================================
;Section RAM (read only) :
	area    mesdata,data,readonly


;Section RAM (read write):
	area    maram,data,readwrite
GestionSon_Index dcd 0 		

	
; ===============================================================================================
	

	
		
;Section ROM code (read only) :		
	area    moncode,code,readonly
; �crire le code ici		
	export GestionSon_callback
	export GestionSon_Index 
	
GestionSon_callback proc
	;push {R0,R1}
	ldr R1,=GestionSon_Index
	ldr R0, [R1]
	add R0, #1
	str R0, [R1]
	;pop{R0, R1}
	bx lr
	endp
		
	END	