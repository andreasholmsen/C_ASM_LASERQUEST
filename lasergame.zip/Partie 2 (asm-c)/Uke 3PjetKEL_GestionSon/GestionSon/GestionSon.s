	PRESERVE8
	THUMB   
		

; ====================== zone de r�servation de donn�es,  ======================================
;Section RAM (read only) :
	area    mesdata,data,readonly


;Section RAM (read write):
	area    maram,data,readwrite
GestionSon_Index dcd 0
SortieSon dcw 0

	
; ===============================================================================================
	

	
		
;Section ROM code (read only) :		
	area    moncode,code,readonly
; �crire le code ici		
	export GestionSon_callback
	export GestionSon_Index
	export SortieSon
	import Son
	import LongueurSon
	extern PWM_Set_Value_TIM3_Ch3
	
; SortieSon = *(Son+GestionSon_Index)
; SortieSon = ((SortieSon+32768)*719)>>16)
; GestionSon_Index ++;

GestionSon_Start proc
	mov R3, #0
	str R3, [R1]
	
	endp
	
GestionSon_callback proc
	ldr R1,=GestionSon_Index
	ldr R12,=LongueurSon
	
	; cmp GestionSon_Index & LongeurSon
	ldr R0, [R1]
	ldr R2, [R12]
	cmp R2, R0
	beq fini
	
	ldr R2,=Son
	; GestionSon_Index = Gestion; *R2 = (*Son+GestionSon_Index)
	ldr R12, [R1]
	lsl R12, R12, #1
	ldrsh R2, [R2,R12]
	
	;R2 = R2 + 32768; R2 = R2*719; R2 >> 16
	add R2, R2, #32768
	mov R3, #719
	mul R2, R2, R3
	asr R2, R2, #16
	
	;SortieSon = *R2
	ldr R3,= SortieSon
	str R2, [R3]
	
	; PWM_Set_Value_TIM3_Ch3(SortieSon)
	mov R0, R2
	push {LR}
	BL PWM_Set_Value_TIM3_Ch3
	pop {LR}
	
	;GestionSon_Index++;
	ldr R1,=GestionSon_Index
	ldr R0, [R1]
	add R0, #1
	str R0, [R1]
	bx lr
	
fini
	bx lr

	endp
		
	END	