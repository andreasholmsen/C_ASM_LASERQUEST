

#include "DriverJeuLaser.h"
#include "ServiceJeuLaser.h"
#include "../GestionSon/GestionSon.h"
#include "DFT.h"
#include "../ServiceDFT/Signal_4_12.h"

/*extern void GestionSon_callback();
extern short int Son;
extern short int SortieSon;
extern long int PeriodeSonMicroSec;*/


#define SEUIL 1000000
#define NBJOUEUR 6
#define Periode_Te_us 5000

	short int DMA_Tab[64];
	
	int pointJoeurs[NBJOUEUR] = {0,0,0,0,0,0};
	int specJoueurs[NBJOUEUR] = {17, 18, 19, 20, 23, 24};
	
	//Le callback
	void IT_function(void){
		ServJeuLASER_StartDMA();
		
		
		
		for (int i = 0; i < NBJOUEUR; i++) {
			int retour = DFT(DMA_Tab, specJoueurs[i]);
			if (retour > SEUIL) {
				GestionSon_Start();
				pointJoeurs[i]++;
				
			}
		}
	}

int main(void)
{
// ===========================================================================
// ============= INIT PERIPH (faites qu'une seule fois)  =====================
// ===========================================================================

/* Apr�s ex�cution : le coeur CPU est clock� � 72MHz ainsi que tous les timers */
	CLOCK_Configure();
	

/* Configuration du son (voir ServiceJeuLaser.h) 
 Ins�rez votre code d'initialisation des parties mat�rielles g�rant le son ....*/	
	GestionSon_Stop();
	ServJeuLASER_Son_Init(PeriodeSonMicroSec,0,GestionSon_callback);
	//GestionSon_Start();
	
	//Configuration
	ServJeuLASER_ADC_DMA(DMA_Tab);

	
	//Interruption
	ServJeuLASER_Systick_IT_Init(Periode_Te_us,0, IT_function);
//============================================================================	
	
	
while	(1)
	{
			// PWM_Set_Value_TIM3_Ch3(SortieSon);
	}
}


