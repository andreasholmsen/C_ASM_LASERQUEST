
void GestionSon_Start();
void GestionSon_callback();
void GestionSon_Stop();

extern long int PeriodeSonMicroSec;