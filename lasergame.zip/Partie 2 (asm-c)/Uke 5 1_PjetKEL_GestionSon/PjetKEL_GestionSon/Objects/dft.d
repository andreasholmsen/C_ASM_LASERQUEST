./objects/dft.o: Principal\DFT.c \
  Principal\..\ServiceDFT\CosSin_Fract_1_15.h \
  Principal\..\Driver\ServiceJeuLaser.h
