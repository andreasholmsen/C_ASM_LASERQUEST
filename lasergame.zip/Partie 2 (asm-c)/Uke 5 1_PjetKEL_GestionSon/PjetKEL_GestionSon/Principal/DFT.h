//float DFT(float * sig, int k);

int DFT(unsigned short int * sig, int k);