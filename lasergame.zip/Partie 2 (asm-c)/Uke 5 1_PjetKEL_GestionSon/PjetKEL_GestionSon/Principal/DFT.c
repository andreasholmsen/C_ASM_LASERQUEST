
//#include "../ServiceDFT/CosSin_float.h"
//#include "../ServiceDFT/Signal_float.h"
//#include "../ServiceDFT/Signal_4_12.h"
#include "../ServiceDFT/CosSin_Fract_1_15.h"
#include "../Driver/ServiceJeuLaser.h"


#define M 64

/*
// 200-250 Microsecondes par appel
float DFT(float * sig, int k) {
	float reel = 0.0;
	float imaginaire = 0.0;
	
	for (int i = 0; i < M; i++) {
		reel += (*(sig+i))*TabCos[(k*i)%M];
		imaginaire += (*(sig+i))*TabSin[(k*i)%M];
	}
	
	return reel*reel+imaginaire*imaginaire;
}
*/

 
 int DFT(short int * sig, int k) {    
		int reel = 0;  // 5.27
    int imaginaire = 0;  // 5.27
		unsigned long long resultat;
   
    for (int i = 0; i < M; i++) {
        reel += (*(sig + i))*TabCos[(k * i) % M]; // 4.12 * 1.15 > 5.27
				imaginaire += (*(sig + i))*TabSin[(k * i) % M]; //  4.12 * 1.15 > 5.27
    }

		resultat = (long long) reel*(long long) reel + (long long) imaginaire*(long long)imaginaire; // 10.54+10.54 
		
		
    return (resultat >> 32); //10.22
}
 

