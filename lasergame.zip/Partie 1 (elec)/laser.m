close all;
clear all;
clc;
Fe = 320000;
DeltaF = 5000;
T = 1/DeltaF;
M = round(Fe/DeltaF);
Te = T/M;
Tsim = T-Te;

F1 = 85005.9;
F2 = 90000;
F3 = 94986.8;
F4 = 100000;
F5 = 115015.9;
F6 = 120000;

Res=sim('simlasergame');

plot(Res.Sinus_Continu);
hold on; % permet de superposer la courbe à suivre
plot(Res.Sinus_Echanti,'o');

Y = abs(fft(Res.Sinus_Echanti.Data))/M;

%for i = 0:(M/2)
    %Y(i+1) = 0.0;
%end

figure;
plot(Y,'o');

lin = (Fe/M)*[0:1:M-1];
stem(lin,Y);

figure;
semilogy(lin,Y,'r*');
grid;
xlabel('échelle de fréquence');
ylabel('amplitude');





