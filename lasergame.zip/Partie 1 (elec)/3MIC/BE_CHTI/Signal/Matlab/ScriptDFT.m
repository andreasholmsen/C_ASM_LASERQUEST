close all;
clc;
T = 0.25;
M = 32;
Te = T/M;
Tsim = T-Te;
Fe = 1/Te;

Fsin = 60;
Res=sim('SimulDFT');

plot(Res.Sinus_Continu);
hold on; % permet de superposer la courbe à suivre
plot(Res.Sinus_Echanti,'o');

Y = abs(fft(Res.Sinus_Echanti.Data))/M;

figure;
plot(Y,'o');

lin = (Fe/M)*[0:1:M-1];
plot(lin,Y);